//List of files which are indexed.
fl = new Array();
fl["0"]= "intro.html";
fl["1"]= "ref.html";
fl["2"]= "t-animal.html";
fl["3"]= "t-cleaning.html";
fl["4"]= "t-projector.html";
fl["5"]= "tp-contact.html";
fl["6"]= "tp-helpers.html";
fl["7"]= "tp-options.html";
fl["8"]= "troubleL.html";
fl["9"]= "troubleP.html";
var doStem = false;searchLoaded = true;