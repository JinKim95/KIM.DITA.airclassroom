//List of files which are indexed.
fl = new Array();
fl["0"]= "intro.html";
fl["1"]= "ref.html";
fl["2"]= "t-cleaning.html";
fl["3"]= "t-projector.html";
fl["4"]= "tp-contact.html";
fl["5"]= "tp-helpers.html";
fl["6"]= "tp-options.html";
fl["7"]= "troubleL.html";
fl["8"]= "troubleP.html";
var doStem = false;searchLoaded = true;